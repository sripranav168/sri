import pandas as pd
import faiss
import numpy as np
from sentence_transformers import SentenceTransformer
from typing import List

class BookingRAG:
    def __init__(self, model_name: str = 'all-MiniLM-L6-v2'):
        self.model = SentenceTransformer(model_name)
        self.index = None
        self.text_chunks = []

    def prepare_data(self, df: pd.DataFrame):
        df_filtered = df[['hotel', 'arrival_date', 'lead_time', 'country', 'is_canceled', 'adr', 'total_nights']]
        df_filtered['arrival_date'] = df_filtered['arrival_date'].astype(str)
        self.text_chunks = df_filtered.apply(
            lambda row: f"{row['hotel']} booking from {row['country']} on {row['arrival_date']} "
                        f"for {row['total_nights']} nights, lead time {row['lead_time']} days, "
                        f"rate {row['adr']}€, {'cancelled' if row['is_canceled'] else 'confirmed'}",
            axis=1
        ).tolist()

    def build_vector_store(self):
        self.embeddings = self.model.encode(self.text_chunks, show_progress_bar=True)
        dim = self.embeddings.shape[1]
        self.index = faiss.IndexFlatL2(dim)
        self.index.add(np.array(self.embeddings))

    def search(self, query: str, top_k: int = 5) -> List[str]:
        query_embedding = self.model.encode([query])
        distances, indices = self.index.search(np.array(query_embedding), top_k)
        return [self.text_chunks[i] for i in indices[0]]

    def generate_answer(self, query: str, context: List[str]) -> str:
        context_block = "\n".join(context)
        prompt = f"Answer the following question based on the data:\n\nContext:\n{context_block}\n\nQuestion: {query}\nAnswer:"
        return f"(Simulated response based on context)\n\n{prompt}"

    def ask(self, query: str) -> str:
        context = self.search(query)
        return self.generate_answer(query, context)
