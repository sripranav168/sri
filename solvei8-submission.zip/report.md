# Implementation Report

## Tools Used
- pandas, seaborn, matplotlib — for data analysis
- sentence-transformers + FAISS — for embedding + retrieval
- FastAPI — to build REST API

## Key Choices
- Used FAISS for fast, in-memory vector search
- Used `all-MiniLM-L6-v2` from SentenceTransformers for fast, compact embeddings

## Challenges
- LLM integration in a local CPU setup is limited (simulated for now)
- Memory optimization for large datasets while vectorizing

## Next Steps (Optional Enhancements)
- Add OpenAI or local LLaMA2 support
- Track query history in a database
- Add real-time updates via SQLite
