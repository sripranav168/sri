# Solvei8 AI/ML Internship Assignment

## 🚀 Project: Hotel Booking Analytics & Q&A System

This project processes hotel booking data, generates analytics, and enables LLM-powered question answering using Retrieval-Augmented Generation (RAG).

---

## 🧠 Features

- 📊 Booking analytics (revenue, cancellations, lead times, etc.)
- 🤖 Natural language Q&A using RAG + SentenceTransformers + FAISS
- 🔌 REST API via FastAPI

---

## 🛠️ Setup Instructions

```bash
pip install -r requirements.txt
python main.py
```

---

## 🧪 API Usage

### 1. GET `/health`
Check if server is running.

### 2. POST `/analytics`
Returns basic analytics summary.

### 3. POST `/ask`

```json
{
  "query": "What is the average booking price?"
}
```

---

## 📁 Dataset
Dataset used: [Hotel Booking Demand - Kaggle](https://www.kaggle.com/datasets/jessemostipak/hotel-booking-demand)
