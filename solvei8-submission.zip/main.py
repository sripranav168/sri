from fastapi import FastAPI
from pydantic import BaseModel
import pandas as pd
from rag_system import BookingRAG
import uvicorn

df = pd.read_csv("your_cleaned_booking_data.csv", parse_dates=['arrival_date'])

rag = BookingRAG()
rag.prepare_data(df)
rag.build_vector_store()

app = FastAPI()

class AskRequest(BaseModel):
    query: str

@app.get("/health")
def health_check():
    return {"status": "ok"}

@app.post("/analytics")
def get_analytics():
    total_revenue = df['total_revenue'].sum()
    cancellation_rate = round(df['is_canceled'].mean() * 100, 2)
    avg_price = round(df[df['is_canceled'] == 0]['adr'].mean(), 2)
    top_countries = df['country'].value_counts().head(5).to_dict()
    return {
        "total_revenue": total_revenue,
        "cancellation_rate": f"{cancellation_rate}%",
        "average_booking_price": avg_price,
        "top_booking_countries": top_countries
    }

@app.post("/ask")
def ask_question(req: AskRequest):
    response = rag.ask(req.query)
    return {"question": req.query, "answer": response}

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)
